CREATE TABLE Country (
    id UUID PRIMARY KEY,
    name VARCHAR(100),
    country_code VARCHAR(10)
);

CREATE TABLE Province (
    id UUID PRIMARY KEY,
    name VARCHAR(100),
    country_id UUID REFERENCES Country(id)
);

CREATE TABLE District (
    id UUID PRIMARY KEY,
    name VARCHAR(100),
    province_id UUID REFERENCES Province(id)
);

CREATE TABLE DipTank (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    is_mobile BOOLEAN,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    name VARCHAR(100),
    tag VARCHAR(100),
    farm_id UUID,
    country_id UUID REFERENCES Country(id),
    is_communal BOOLEAN
);

CREATE TABLE Farm (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    street_address TEXT,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    name VARCHAR(150),
    organization_id UUID,
    owner_id UUID,
    country_id UUID REFERENCES Country(id),
    province_id UUID REFERENCES Province(id),
    district_id UUID REFERENCES District(id),
    is_communal BOOLEAN,
    communal_diptank_id UUID,
    deleted_at TIMESTAMP
);

CREATE TABLE Herd (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    name VARCHAR(100),
    farm_id UUID REFERENCES Farm(id),
    last_stock_count_id UUID,
    is_communal BOOLEAN,
    deleted_at TIMESTAMP
);

CREATE TABLE Animal (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    birth_date_time TIMESTAMP,
    death_date_time TIMESTAMP,
    e_livestock_tag VARCHAR(100),
    event_stream_id VARCHAR(100),
    father_e_livestock_tag VARCHAR(100),
    lit_or_farm_tag VARCHAR(100),
    mother_e_livestock_tag VARCHAR(100),
    color_attribute VARCHAR(50),
    has_dna_info BOOLEAN,
    has_ear_notch BOOLEAN,
    has_retinal_scan BOOLEAN,
    primary_color VARCHAR(50),
    secondary_color VARCHAR(50),
    sex VARCHAR(10),
    species VARCHAR(50),
    status VARCHAR(50),
    farm_id UUID REFERENCES Farm(id),
    herd_id UUID REFERENCES Herd(id),
    is_communal BOOLEAN
);

CREATE TABLE AnimalEvent (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    animal_e_livestock_tag VARCHAR(100),
    event_date_time TIMESTAMP,
    event_type VARCHAR(100),
    stream_index INT,
    animal_id UUID REFERENCES Animal(id),
    event_id UUID,
    tx_id TEXT,
    tx_confirmed BOOLEAN,
    blockchain_payload_id TEXT,
    notary_provider VARCHAR(100)
);

CREATE TABLE Event (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    color_attribute VARCHAR(50),
    has_dna_info BOOLEAN,
    has_ear_notch BOOLEAN,
    has_retinal_scan BOOLEAN,
    primary_color VARCHAR(50),
    secondary_color VARCHAR(50),
    sex VARCHAR(10),
    species VARCHAR(50),
    assigned_herd_name VARCHAR(100),
    birth_date TIMESTAMP,
    e_livestock_tag VARCHAR(100),
    father_e_livestock_tag VARCHAR(100),
    lit_or_farm_tag VARCHAR(100),
    mother_e_livestock_tag VARCHAR(100),
    animal_count INT,
    dip_chemical VARCHAR(100),
    dip_type VARCHAR(100),
    event_date_time TIMESTAMP,
    event_type VARCHAR(100),
    health_event_description TEXT,
    loss_date_time TIMESTAMP,
    loss_type VARCHAR(100),
    note TEXT,
    extra_animals INT,
    missing_animals INT,
    present_animals INT,
    change_date_time TIMESTAMP,
    new_tag_number VARCHAR(100),
    old_tag_number VARCHAR(100),
    units VARCHAR(20),
    weight DOUBLE PRECISION,
    assigned_herd_id UUID,
    diptank_id UUID REFERENCES DipTank(id),
    farm_id UUID REFERENCES Farm(id),
    counted_herd_id UUID,
    user_id UUID,
    death_type VARCHAR(100),
    death_date_time TIMESTAMP,
    longitude DOUBLE PRECISION,
    latitude DOUBLE PRECISION,
    user_role VARCHAR(50),
    old_herd_id UUID,
    new_herd_id UUID,
    from_transfer_request_id UUID,
    transfer_request_id UUID
);

CREATE TABLE Organization (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    street_address TEXT,
    name VARCHAR(150),
    national_id_number VARCHAR(100),
    tax_id_number VARCHAR(100),
    owner_id UUID,
    country_id UUID REFERENCES Country(id),
    province_id UUID REFERENCES Province(id),
    district_id UUID REFERENCES District(id)
);

CREATE TABLE Role (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    role VARCHAR(50),
    farm_id UUID,
    organization_id UUID REFERENCES Organization(id),
    user_id UUID,
    country_id UUID REFERENCES Country(id)
);

CREATE TABLE "User" (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    email VARCHAR(150),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    password TEXT,
    phone_number VARCHAR(50),
    national_id_number VARCHAR(100)
);

CREATE TABLE TransferRequest (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    status VARCHAR(50),
    receiving_farm_id UUID REFERENCES Farm(id),
    sending_farm_id UUID REFERENCES Farm(id)
);

CREATE TABLE TransferRequestAnimal (
    transfer_request_id UUID REFERENCES TransferRequest(id),
    animal_id UUID REFERENCES Animal(id),
    PRIMARY KEY (transfer_request_id, animal_id)
);

CREATE TABLE Notification (
    id UUID PRIMARY KEY,
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    animal_e_livestock_tag VARCHAR(100),
    event_id UUID,
    event_type VARCHAR(100),
    error_code VARCHAR(100),
    farm_id UUID REFERENCES Farm(id),
    user_id UUID REFERENCES "User"(id),
    herd_id UUID REFERENCES Herd(id),
    dip_tank_id UUID REFERENCES DipTank(id),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(150),
    role VARCHAR(100)
);

CREATE TABLE FlywaySchemaHistory (
    installed_rank INT PRIMARY KEY,
    version VARCHAR(50),
    description TEXT,
    type VARCHAR(50),
    script TEXT,
    checksum INT,
    installed_by VARCHAR(100),
    installed_on TIMESTAMP,
    execution_time INT,
    success BOOLEAN
);

SELECT COUNT(*) FROM Farm;
